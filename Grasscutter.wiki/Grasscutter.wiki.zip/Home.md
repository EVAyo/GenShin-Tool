Welcome to the Grasscutter wiki!

# Connecting
A tutorial for connecting to a server can be found [here](https://github.com/Melledy/Grasscutter/wiki/Running#connecting).
# Running the Server
A guide for running the server can be found [here](https://github.com/Melledy/Grasscutter/wiki/Running#starting-the-server).
# Troubleshooting
Commonly reported errors and their solutions can be found [here](https://github.com/Grasscutters/Grasscutter/wiki/Troubleshooting).
# Building from Source
For information about building from source, consult [this guide](https://github.com/Melledy/Grasscutter/wiki/Building).